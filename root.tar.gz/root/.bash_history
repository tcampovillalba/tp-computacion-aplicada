history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl set-hostname TPServer --static
hostname
poweroff
cat /etc/os-release
cat /etc/apt/sources.list
cat /etc/debian_version
apt-get update
apt-get dist-upgrade
dpkg --configure -a
apt-get -f install
apt-get update
apt-get dist-upgrade
reboot
cat /etc/debain_version
cat /etc/debian_version
uname -r
cat /etc/apt/sources.list
poweroff
cp /etc/apt/sources.list /etc/apt/sources.list.bullseye
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
sed -i {.{^# deb/deb/' /etc/apt/sources.list
ses -i 's/non-free$/non-free non-free-firmware/' /etc/apt/sources.list
cat /etc/aptsources.list
sed -i 's/# deb/deb/' /etc/ept/sources.list
sed -i 's/# deb/deb/' /etc/apt/sources.list
sed -i 's/non-free$/non-free non-free-firware/' /etc/apt/sources.list
cat /etc/apt/sources.list
sed -i 's/firware/firmware/g' /etc/apt/sources.list
cat /etc/apt/sources.list 
apt-get update
power off
poweroff
apt-get upgrade
apt-get upgrade
poweroff
apt-get upgrade
apt-get full-upgrade
ls /boot | grep vmlinuz
reboot
cat /etc/os-release
uname -r
apt-get full-upgrade
apt-get autoremove
poweroff
exit
cat /etc/hosts
sed -i 's/debian/TPServer/' /etc/hosts
cat /etc/hosts
php -v
apachectl -M | GREP PHP
apache2ctl -M | grep php
cd /root/Material_Adicional_TPVMCA
cp index.php logo.png /var/www/html
mv /var/www/html/index.html /var/www/html/index.html.bak
chmod 644 /var/www/html/index.php /var/www/html/logo.png 
ls -la /var/www/html
curl http://localhost
curl -I http://localhost/logo.png
cat /etc/hosts
php -v
apache2ctl -M | grep php
cp index.php logo.png /var/www/html
mv /var/www/html/index.html /var/www/html/index.html.bak
ls -la
ls -la /var/www/html
curl http://localhost
curl -I http://localhost
tail -5 /var/log/apache2/error.log
curl -I http://localhost/logo.png
cd /root/Material_Adicional_TPVMCA
grep -i create db.sql
grep -i use db.sql
apt-get install mariadb-server
systemctl status mariadb --no-pager
curl -I http://localhost
tail -1 /var/log/apache2/error.log
grep -i create db.sql
grep -i use db.sql
cat db.sql
mariabd > db.sql
mariadb < bd.sql
mariadb < db.sql
mariadb -e "SHOW DATABASES;"
mariadb ingenieria -e "SHOW TABLES;"
mariadb < db.sql
mariadb -e "SHOW DATABAESE;"
mariadb -e "SHOW DATABASES;"
mariadb ingenieria -e "SHOW TABLES;"
MARIADB
mariadb
file db.sql
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz --no-same-owner -C /root Material_Adicional_TPVMCA/db.sql
ls -l db.sql
file db.sql
ls -la
mariadb < db.sql
mariadb -e "SHOW DATABASES;"
mariadb ingenieria -e "SHOW TABLES;"
mariadb -u lcars -p ingenieria -e "SELECT * FROM alumnos;"
curl http://localhost
curl -I http://localhost
poweroff
ipconfig
ip a
ip rout
ip route
poweroff
ip a
cat /etc/network/interfaces
cp /etc/network/interfaces /etc/network/interfaces.bak
sed -i 's/iface enp0s3 inet dhcp/iface enp0s3 inet static/' /etc/network/interfaces
echo " address192.168.0.150" >> /etc/network/interfaces
sed -i 's/adress192.168.0150/address 192.168.0.150/' /etc/network/interfaces
echo " netmask 255.255.255.0" >> /etc/netwoek/interfaces
echo " netmask 255.255.255.0" >> /etc/network/interfaces
echo " gateway 192.168.0.1" >> /etc/network/interfaces
cat /etc/network/interfaces
sed -i 's/address192/address 192/' /etc/network/interfaces
cat /etc/network/interfaces
reboot
ip a
ip route
ip route[3~
ping -c 192.168.0.1
ping -c 3 192.168.0.1
ping -c 3 deb.debian.org
ping -4 -c 3 deb.debian.org
ping 192.168.0150
cppower
poweroff
cp /root/Material_Adicional_TPVMCA/clave_privada.txt /var/www/html/clave_temp.txt
chmod 644 /var/www/html/clave/temp.text
chmod 644 /var/www/html/clave_html.txt
çhomd 644 /var/www/html/clave_temp.txt
chmod 644 /var/www/html/clave_temp.txt
ls /var/www/html
cp /root/Material_Adicional_TPVMA/clave_privada.txt /var/www/html/clave_temp.txt
cp /root/Material_Adicional_TPVMCA/clave_privada.txt /var/www/html/clave_temp.txt
chmod 644 /var/www/html/clave_temp.txt
rm /var/www/html/clave_temp.txt
poweroff
poweroff
hostname; ls /var/www/html; curl -sI http://localhost/clave_temp.txt | head -1
lsblk
poweroff
lsblsk
lsblk
printf 'n\np\n1\n\n+3G\nn\np\n2\n\n+6G\nw\n' | fdisk /dev/sdc
fdisk -l /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
cat /etc/fstab
mount -a
mkdir /www_dir /buckup_dir
cat /pcroc/partitions > /opt/particion
cat /proc/partitions > /opt/particion
cat /opt/particion
cp /etc/fstab /etc/fstab.bak
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2) /backup_dir ext4 defaults 0 2" >> /etc/fstab
systemctl daemon-reload
mount -a
df -h /www_dir /backup_dir
mv /buckup_dir /backup_dir
mount -a
df -h /www_dir /backup_dir
cat /etc/fstab
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls -la /www_dir
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.ba
cp /etc/apache2/sites-available/00-default.conf /etc/apache2/sites-available/000-default.conf.bak
cp /etc/apache2/sites-available/00-default.conf /etc/apache2/sites-available/000-default.conf.bak
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
sed -i 's#/var/www/html#/www_dir#' /etc/apache2/sites-available/000-default.conf
grep DocumentRoot /etc/apache2/sites-avaible/000-default.conf
grep DocumentoRoot /etc/apache2/sites-available/000default.conf
grep DocumentRoot /etc//apache2/sites-avaible/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
cp /etc/apache2/apche2.conf /etc/apache2/apache2.conf.bak
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.bak
printf '\n<Directory /www_dir/>\n\tOptions FollowSymLinks\n\tAllowOverride None\n\tRequire all granted\n>/Directory>\n' >> /etc/apache2/apache2.conf
-6 /etc/apache2/apache2.conf
tail -6 /etc/apache2/apache.conf
tail -6 /etc/apache2/apche2.conf
tail -6 /etc/apache2/apache2.conf
cd /etc/apache2
cp apache2.conf apache.conf.bak
echo '<Directory /www_dir/>' >> apache2.conf
echo 'Options FollowSymLinks' >> apache2.conf
echo 'AllowOverride None' >> apache2.conf
echo 'Require all granted' >> apache2.conf
echo '</Directory>' >> apache2.conf
tail -6 apache.conf
tail -6 apache2.conf
cd
apache2ctl configtest
tail -6 /etc/apache2/apache2.conf
tail -3 /etc/apache2/apache2.conf.bak
cp /etc/apache2/apache2.conf.bak /etc/apache2/apache2.conf
cp /etc/apache2
cd /etc/apache2
echo '<Directory /www_dir>' >> apache2.conf
echo 'AllowOverride None' >> apache2.conf
echo 'Require all granted' >> apache2.conf
echo '</Directory>' >> apache2.conf
tail -6 apache2.conf
apache2ctl configtest
systemctl reload apache2
curl -I http://localhost
cd
echo "Servido desde www_dir" > /www_dir/prueba.txt
curl http://localhost/prueba.txt
rm /www_dir/prueba.txt
reboot
ipconfig
ip config
df -h /www_dir /backup_dir
curl -I http://loclahost
date
date
curl -I http://localhost
poweroff
cat > /opt/scripts/backup_full.sh << 'EOF'
#!/bin/bash
# ============================================================
# backup_full.sh - Script de backup
# Uso:     backup_full.sh ORIGEN DESTINO
# Ejemplo: backup_full.sh /var/log /backup_dir
#          genera /backup_dir/log_bkp_AAAAMMDD.tar.gz
# ============================================================

# --- Funcion de ayuda (punto 5.5) ---
mostrar_ayuda() {
    echo "Uso: $0 ORIGEN DESTINO"
    echo ""
    echo "Comprime el directorio ORIGEN en un archivo .tar.gz"
    echo "y lo guarda en el directorio DESTINO."
    echo "El nombre del archivo incluye la fecha: NOMBRE_bkp_AAAAMMDD.tar.gz"
    echo ""
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "         genera /backup_dir/log_bkp_$(date +%Y%m%d).tar.gz"
    echo ""
    echo "Opciones:"
    echo "  -help   Muestra esta ayuda"
}

# --- Funcion de validacion de montaje (punto 5.6) ---
# Si el directorio figura en /etc/fstab como punto de montaje,
# la particion tiene que estar montada.
verificar_montaje() {
    if grep -qE "[[:space:]]$1[[:space:]]" /etc/fstab && ! mountpoint -q "$1"; then
        echo "Error: $1 deberia estar montado y no lo esta."
        exit 1
    fi
}

# 1) Opcion de ayuda (punto 5.5)
if [ "$1" = "-help" ]; then
    mostrar_ayuda
    exit 0
fi

# 2) Validar que haya 2 argumentos (punto 5.4)
if [ $# -ne 2 ]; then
    echo "Error: se necesitan 2 argumentos: ORIGEN y DESTINO."
    echo "Use '$0 -help' para ver la ayuda."
    exit 1
fi

# Guardar los argumentos sin la barra final
ORIGEN="${1%/}"
DESTINO="${2%/}"

# 3) Validar el origen (punto 5.6)
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen $ORIGEN no existe o no es un directorio."
    exit 1
fi
verificar_montaje "$ORIGEN"

# 4) Validar el destino (punto 5.6)
if [ ! -d "$DESTINO" ]; then
    echo "Error: el destino $DESTINO no existe o no es un directorio."
    exit 1
fi
if [ ! -w "$DESTINO" ]; then
    echo "Error: no se puede escribir en el destino $DESTINO."
    exit 1
fi
verificar_montaje "$DESTINO"

# 5) Armar el nombre con la fecha en formato ANSI (punto 5.2)
NOMBRE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# 6) Crear el backup comprimido
echo "Haciendo backup de $ORIGEN en $ARCHIVO ..."
if tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"; then
    echo "Backup terminado: $ARCHIVO"
    exit 0
else
    echo "Error: fallo el backup de $ORIGEN."
    exit 1
fi
EOF

echo 'auto enp0s8' >> /etc/network/interfaces
echo 'iface enp0s8 inet static' >> /etc/network/interfaces
echo 'address 192.168.56.10' >> /etc/network/interfaces
echo 'netmask 255.255.255.0' >> /etc/network/interfaces
ifup enp0s8
ip a show enp0s8
echo 'auto enp0s8' >> /etc/network/intefaces
echo 'iface enp0s8 inet static' >> /etc/network/interfaces
echo 'address 192.168.56.10' >> /etc/network/interfaces
echo ' netmask 255.255.255.0' >> /etc/network/interfaces
ifup enp0s8
ip a show enp0s8
rm /etc/network/intefaces
cat /etc/network/interfaces
cp /etc/network/interfaces /etc/network/interfaces.bak2
sed -i '$d' /etc/network/interfaces
seb -i '$d' /etc/network/interfaces
sed -i '$d' /etc/network/interfaces
sed -i 's/^auto enp0s8/\n# Red Host-Only \nauto enp0s8/
sed -i 's/^auto enp0s8/\n# Red Host-Only \nauto enp0s8/'
cat /etc/network/interfaces
sed -i '$d' /etc/network/interfaces
cat /etc/network/interfaces
mkdir -p /opt/scripts
wc -l /opt/scripts/bacuk_full.sh && echo "SINTAXIS OK"
wC -l /opt/scripts/backup_full.sh
ls -l /opt/scripts
wc -l /opt/scripts
wc -l /opt/script/backup_full.sh
reboot
chmod 700 /opt/script/backup_full.sh
ls -l /opt/scripts
cd /opt/scripts
./backup_full.sh -help
chmod 700 backup_full.sh
ls -l
./backup_full.sh -help
./backup_full.sh
./backup_full.sh /noexiste /backup_dir
./backup_full.sh /var/log /backup_dir
./backup_full.sh /www_dir /backup_dir
ls -l /backup_dir
echo '00*** /opt/scripts/backup_full.sh /var/log /backup_dir' > /root/tareas
echo '0 23 ** 1,3,5 /opt/scripts/backup_full.sh /www_dir /backup_dir' >> /root/tareas
crontab /root/tareas
cat /root/tareas
cd /opt/scripts
rm backup_full.sh
vi backup_full.sh
chmod 700 backup_full.sh
bash -n backup_full.sh
vi backup_full.sh
bash -n backup_full.sh
:11
vi backup_full.sh
bash -n backup_full.sh
vi backup_full.sh
bash -n backup_full.sh
./backup_full.sh -help
./backup_full.sh
./backup_full.sh /noexiste /backup_dir
./backup_full.sh /var/log backup_dir
./backup_full.sh /www_dir /backup_dir
ls -l /backup_dir
./backup_full.sh /var/log /backup_dir
ls -l /backup_dir
rm /root/tareas
cp /etc/contab /etc/crontab.bak
vi /etc/crontab
vi /etc/crontab
systemctl status cron
php -v
apache2ctl -M | grep php
curl -I http://localhost/logo.png
lsblk
fdick -l /dev/sdc
fdisk -l /dev/sdc
blkid /dev/sdc1 /dev/sdc2
cat -n /opt/scripts/backup_full.sh
php -v
apache2ctl -M | grep php
curl -I http://localhost/logo.png
lsblk
fdisk -l /dev/sdc
blkid /dev/sdc1 /dev/sdc2
cat -n /opt/scripts/backup_full.sh
tail -5 /var/log/apache2/access.log
tail -5 /var/log/apache2/access.log
poweroff
tail - /var/log/apache2/access.log
cd /opt/scripts
tail -5 /var/log/apache2/access.log
poweroff
df 'h - -backup?dirñ du 'sh -root -etc -opt -www?dir -backup?dir -var
loadkeys us
df 'h - -backup?dirñ du 'sh -root -etc -opt -www?dir -backup?dir -var
exit

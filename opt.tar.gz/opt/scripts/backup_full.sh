#!/bin/bash
#backup_full.sh - Backup de un directorio
#Uso: backup_full.sh ORIGEN DESTINO

if [ "$1" = "-help" ]; then
echo "Uso: $0 ORIGEN DESTINO"
echo "Ejemplo: $0 /var/log /backup_dir"
echo "Genera: /backup_dir/log_bkp_AAAAMMDD.tar.gz"
exit 0
fi

if [ $# -ne 2 ]; then
echo "Error: faltan argumentos. Use: $0 -help" 
exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d $ORIGEN ]; then
echo "Error: el origen $ORIGEN no existe" 
exit 1 
fi

mount | grep -q " $DESTINO "
if [ $? -ne 0 ]; then
echo "Error: $DESTINO no esta montado"
exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)
tar -czf $DESTINO/${NOMBRE}_bkp_$FECHA.tar.gz $ORIGEN
if [ $? -eq 0 ]; then
echo "OK: backup en $DESTINO/${NOMBRE}_bkp_$FECHA.tar.gz"
else
echo "Error: fallo el backup"
fi
